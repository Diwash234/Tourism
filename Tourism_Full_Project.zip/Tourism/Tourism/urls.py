from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static
from drf_spectacular.views import (
    SpectacularAPIView,
    SpectacularSwaggerView,
    SpectacularRedocView,
)

urlpatterns = [
    path("admin/", admin.site.urls),
    path("api/v1/admin-panel/", include("admin_panel.urls")),
    path("api/v1/", include("booking.urls")),
    path("api/v1/chatbot/", include("chatbot.urls")),
    # path("api/v1/safety/", include("safety.urls")),
    # path("api/v1/", include("translation.urls")),
    # path("api/v1/", include("media_app.urls")),
    path("api/v1/", include("tourist.urls")),

    # Swagger / OpenAPI
    path("api/schema/", SpectacularAPIView.as_view(), name="schema"),
    path("api/docs/", SpectacularSwaggerView.as_view(url_name="schema"), name="swagger-ui"),
    path("api/redoc/", SpectacularRedocView.as_view(url_name="schema"), name="redoc"),
]
    
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)