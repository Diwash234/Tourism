import uuid

from django.conf import settings
from django.contrib.auth.models import AbstractBaseUser, PermissionsMixin
from django.core.validators import MinValueValidator, MaxValueValidator
from django.db import models
from django.utils import timezone
from django.utils.text import slugify
from phonenumber_field.modelfields import PhoneNumberField

from .managers import UserManager


class TimeStampedModel(models.Model):
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        abstract = True


# ---------------------------------------------------------------------------
# Languages & Users
# ---------------------------------------------------------------------------
class Language(models.Model):
    """Supported languages for translation & user preference."""

    code = models.CharField(max_length=10, unique=True, help_text="ISO 639-1 code, e.g. 'en', 'fr', 'ne'")
    name = models.CharField(max_length=50)
    is_active = models.BooleanField(default=True)

    class Meta:
        ordering = ["name"]

    def __str__(self):
        return f"{self.name} ({self.code})"


class User(AbstractBaseUser, PermissionsMixin):
    class Role(models.TextChoices):
        # Original 3 kept as-is (existing users/checks referencing these
        # values keep working unchanged) -- 10 more added per the RBAC spec.
        TOURIST = "tourist", "Tourist"
        GUIDE = "guide", "Local Guide"
        ADMIN = "admin", "Admin"
        SUPER_ADMIN = "super_admin", "Super Admin"
        TOURISM_ADMIN = "tourism_admin", "Tourism Admin"
        CONTENT_MODERATOR = "content_moderator", "Content Moderator"
        DISTRICT_MANAGER = "district_manager", "District Manager"
        HOTEL_MANAGER = "hotel_manager", "Hotel Manager"
        STAFF = "staff", "Staff"
        TOURIST_POLICE = "tourist_police", "Tourist Police"
        POLICE = "police", "Police"
        HOSPITAL_STAFF = "hospital_staff", "Hospital Staff"
        RESCUE_TEAM = "rescue_team", "Rescue Team"
        EMERGENCY_OPERATOR = "emergency_operator", "Emergency Operator"

    email = models.EmailField(unique=True)
    first_name = models.CharField(max_length=100, blank=True)
    last_name = models.CharField(max_length=100, blank=True)
    phone_number = PhoneNumberField(blank=True, null=True)
    phone_verified = models.BooleanField(default=False)

    class AuthProvider(models.TextChoices):
        EMAIL = "email", "Email/Password"
        GOOGLE = "google", "Google"
        GITHUB = "github", "GitHub"

    auth_provider = models.CharField(max_length=20, choices=AuthProvider.choices, default=AuthProvider.EMAIL)
    provider_uid = models.CharField(
        max_length=255, blank=True,
        help_text="The account ID from Google/GitHub, used to re-link on subsequent OAuth logins."
    )
    role = models.CharField(max_length=20, choices=Role.choices, default=Role.TOURIST)
    managed_district = models.CharField(
        max_length=100, blank=True,
        help_text="For District Manager role: which district this user can manage. Blank = no district restriction."
    )
    profile_picture = models.ImageField(upload_to="profile_pictures/", blank=True, null=True)
    bio = models.TextField(blank=True)

    preferred_language = models.ForeignKey(
        Language, on_delete=models.SET_NULL, null=True, blank=True, related_name="users"
    )

    # Location - set from browser GPS first, GeoIP as fallback (see middleware.py)
    latitude = models.DecimalField(max_digits=9, decimal_places=6, null=True, blank=True)
    longitude = models.DecimalField(max_digits=9, decimal_places=6, null=True, blank=True)
    country = models.CharField(max_length=100, blank=True)
    city = models.CharField(max_length=100, blank=True)
    location_source = models.CharField(
        max_length=10,
        choices=[("gps", "Browser GPS"), ("geoip", "GeoIP"), ("manual", "Manual")],
        blank=True,
    )

    is_verified = models.BooleanField(default=False)
    is_active = models.BooleanField(default=True)
    is_staff = models.BooleanField(default=False)
    date_joined = models.DateTimeField(default=timezone.now)

    objects = UserManager()

    USERNAME_FIELD = "email"
    REQUIRED_FIELDS = []

    class Meta:
        ordering = ["-date_joined"]

    def __str__(self):
        return self.email

    @property
    def full_name(self):
        return f"{self.first_name} {self.last_name}".strip() or self.email


class EmailVerificationToken(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="email_tokens")
    token = models.UUIDField(default=uuid.uuid4, editable=False, unique=True)
    created_at = models.DateTimeField(auto_now_add=True)
    expires_at = models.DateTimeField()
    is_used = models.BooleanField(default=False)

    def is_valid(self):
        return not self.is_used and timezone.now() < self.expires_at


class SMSVerificationToken(models.Model):
    """
    6-digit OTP sent via Twilio to verify a phone number. Mirrors
    EmailVerificationToken's shape/pattern but uses a short numeric code
    (not a UUID) since it has to be readable and typeable from an SMS.
    """
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="sms_tokens")
    code = models.CharField(max_length=6)
    created_at = models.DateTimeField(auto_now_add=True)
    expires_at = models.DateTimeField()
    is_used = models.BooleanField(default=False)
    attempt_count = models.PositiveSmallIntegerField(default=0)  # brute-force guard

    def is_valid(self):
        return not self.is_used and self.attempt_count < 5 and timezone.now() < self.expires_at


class PasswordResetToken(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="reset_tokens")
    token = models.UUIDField(default=uuid.uuid4, editable=False, unique=True)
    created_at = models.DateTimeField(auto_now_add=True)
    expires_at = models.DateTimeField()
    is_used = models.BooleanField(default=False)

    def is_valid(self):
        return not self.is_used and timezone.now() < self.expires_at


# ---------------------------------------------------------------------------
# Tourism module
# ---------------------------------------------------------------------------
class Category(models.Model):
    name = models.CharField(max_length=100, unique=True)
    slug = models.SlugField(max_length=120, unique=True, blank=True)
    icon = models.CharField(max_length=50, blank=True, help_text="Icon name / css class for frontend")
    description = models.TextField(blank=True)

    class Meta:
        verbose_name_plural = "Categories"
        ordering = ["name"]

    def save(self, *args, **kwargs):
        if not self.slug:
            self.slug = slugify(self.name)
        super().save(*args, **kwargs)

    def __str__(self):
        return self.name


class Destination(TimeStampedModel):

    class SubmissionStatus(models.TextChoices):
        PENDING = "pending", "Pending Review"
        APPROVED = "approved", "Approved"
        REJECTED = "rejected", "Rejected"
        ARCHIVED = "archived", "Archived"


    external_id = models.IntegerField(
        unique=True,
        null=True,
        blank=True
    )

    name = models.CharField(
        max_length=200
    )

    slug = models.SlugField(
        max_length=220,
        unique=True,
        blank=True
    )

    city_nepali = models.CharField(
        max_length=200,
        blank=True,
        null=True
    )

    city_english = models.CharField(
        max_length=200,
        blank=True,
        null=True
    )
    category = models.ForeignKey(
        Category,
        on_delete=models.PROTECT,
        related_name="destinations",
        null=True,
        blank=True
    )


    type = models.CharField(
        max_length=100,
        blank=True,
        null=True
    )


    description = models.TextField(
        blank=True,
        null=True
    )


    short_description = models.CharField(
        max_length=300,
        blank=True,
        null=True
    )


    district = models.CharField(
        max_length=100,
        blank=True,
        null=True
    )

    municipality = models.CharField(
        max_length=150,
        blank=True,
        null=True,
        help_text="Metropolitan, Sub-Metropolitan, Municipality, or Rural Municipality (Gaunpalika)"
    )

    ward_number = models.PositiveSmallIntegerField(
        blank=True,
        null=True,
        help_text="Local Ward Number (e.g. 1 to 35)"
    )

    province = models.CharField(
        max_length=100,
        blank=True,
        null=True
    )


    source = models.CharField(
        max_length=100,
        blank=True,
        null=True
    )


    cover_image = models.ImageField(
        upload_to="destinations/cover/",
        blank=True,
        null=True
    )


    # GPS coordinates
    latitude = models.DecimalField(
        max_digits=9,
        decimal_places=6,
        blank=True,
        null=True
    )

    longitude = models.DecimalField(
        max_digits=9,
        decimal_places=6,
        blank=True,
        null=True
    )


    address = models.CharField(
        max_length=255,
        blank=True,
        null=True
    )


    city = models.CharField(
        max_length=100,
        blank=True,
        null=True
    )


    country = models.CharField(
        max_length=100,
        blank=True,
        null=True
    )


    opening_hours = models.CharField(
        max_length=255,
        blank=True,
        null=True
    )

    history = models.TextField(
        blank=True,
        null=True,
        help_text="Historical, religious, or cultural background"
    )

    best_time_to_visit = models.CharField(
        max_length=255,
        blank=True,
        null=True,
        help_text="e.g. Sep-Nov (Autumn) & Mar-May (Spring)"
    )

    altitude = models.CharField(
        max_length=100,
        blank=True,
        null=True,
        help_text="Altitude in meters (e.g. 1,400m / 5,364m)"
    )

    nearest_hospital_info = models.CharField(
        max_length=255,
        blank=True,
        null=True
    )

    nearest_hotel_info = models.CharField(
        max_length=255,
        blank=True,
        null=True
    )

    nearest_police_info = models.CharField(
        max_length=255,
        blank=True,
        null=True
    )

    entry_fee = models.DecimalField(
        max_digits=8,
        decimal_places=2,
        default=0,
        blank=True,
        null=True
    )


    contact_phone = PhoneNumberField(
        blank=True,
        null=True
    )


    contact_email = models.EmailField(
        blank=True,
        null=True
    )


    website = models.URLField(
        blank=True,
        null=True
    )


    average_rating = models.DecimalField(
        max_digits=3,
        decimal_places=2,
        default=0
    )


    ratings_count = models.PositiveIntegerField(
        default=0
    )


    views_count = models.PositiveIntegerField(
        default=0
    )


    created_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="destinations_created"
    )


    is_user_submitted = models.BooleanField(
        default=False
    )


    status = models.CharField(
        max_length=20,
        choices=SubmissionStatus.choices,
        default=SubmissionStatus.APPROVED
    )


    review_note = models.CharField(
        max_length=255,
        blank=True,
        null=True,
        help_text="Admin note, e.g. reason for rejection"
    )


    is_active = models.BooleanField(
        default=True
    )


    class Meta:
        ordering = ["-created_at"]

        indexes = [
            models.Index(fields=["latitude", "longitude"]),
            models.Index(fields=["city", "country"]),
            models.Index(fields=["status"]),
        ]


    def save(self, *args, **kwargs):

        if not self.slug:
            base_slug = slugify(self.name)
            slug = base_slug
            counter = 1

            while Destination.objects.filter(slug=slug).exclude(pk=self.pk).exists():
                slug = f"{base_slug}-{counter}"
                counter += 1

            self.slug = slug

        super().save(*args, **kwargs)


    def __str__(self):
        return self.name


    def recalculate_rating(self):

        agg = self.ratings.aggregate(
            avg=models.Avg("value"),
            count=models.Count("id")
        )

        self.average_rating = round(agg["avg"] or 0, 2)
        self.ratings_count = agg["count"] or 0

        self.save(
            update_fields=[
                "average_rating",
                "ratings_count"
            ]
        )


class DestinationTranslation(models.Model):
    """Stores machine-translated copies of a destination's text fields."""

    destination = models.ForeignKey(Destination, on_delete=models.CASCADE, related_name="translations")
    language = models.ForeignKey(Language, on_delete=models.CASCADE)
    name = models.CharField(max_length=200)
    description = models.TextField()
    short_description = models.CharField(max_length=300, blank=True)
    is_auto_generated = models.BooleanField(default=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        unique_together = ("destination", "language")

    def __str__(self):
        return f"{self.destination.name} [{self.language.code}]"


class DestinationImage(TimeStampedModel):
    class Source(models.TextChoices):
        ADMIN = "admin", "Admin Upload"
        USER_UPLOAD = "user_upload", "Community Upload"
        UNSPLASH = "unsplash", "Unsplash"
        WIKIMEDIA = "wikimedia", "Wikimedia Commons"
        GOOGLE_PLACES = "google_places", "Google Places"
        FOURSQUARE = "foursquare", "Foursquare"

    destination = models.ForeignKey(Destination, on_delete=models.CASCADE, related_name="gallery")
    image = models.ImageField(upload_to="destinations/gallery/", blank=True, null=True)
    external_url = models.URLField(
        blank=True, help_text="Used instead of `image` for externally-hosted photos (Unsplash/Wikimedia/etc.)"
    )
    caption = models.CharField(max_length=200, blank=True)
    is_cover = models.BooleanField(default=False)

    source = models.CharField(max_length=20, choices=Source.choices, default=Source.ADMIN)
    verification_status = models.CharField(
        max_length=20,
        choices=[("pending", "Pending"), ("approved", "Approved"), ("rejected", "Rejected")],
        default="approved"
    )
    is_verified = models.BooleanField(default=True)
    uploaded_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True, related_name="uploaded_photos"
    )
    attribution = models.CharField(
        max_length=255, blank=True, help_text="Required for Unsplash/Wikimedia per their license terms"
    )
    is_promoted = models.BooleanField(
        default=False, help_text="Auto-set true once a community upload crosses the popularity threshold"
    )
    view_count = models.PositiveIntegerField(default=0)

    class Meta:
        ordering = ["-is_cover", "-is_promoted", "-view_count", "-created_at"]

    def __str__(self):
        return f"{self.destination.name} photo ({self.get_source_display()})"


class DestinationVideo(TimeStampedModel):
    destination = models.ForeignKey(Destination, on_delete=models.CASCADE, related_name="videos")
    video_url = models.URLField(help_text="YouTube/Vimeo link or hosted video URL")
    title = models.CharField(max_length=200, blank=True)
    thumbnail = models.ImageField(upload_to="destinations/video_thumbnails/", blank=True, null=True)


class Review(TimeStampedModel):
    destination = models.ForeignKey(Destination, on_delete=models.CASCADE, related_name="reviews")
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="reviews")
    comment = models.TextField()
    is_flagged = models.BooleanField(default=False)

    class Meta:
        ordering = ["-created_at"]
        unique_together = ("destination", "user")


class Rating(TimeStampedModel):
    destination = models.ForeignKey(Destination, on_delete=models.CASCADE, related_name="ratings")
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="ratings")
    value = models.PositiveSmallIntegerField(validators=[MinValueValidator(1), MaxValueValidator(5)])

    class Meta:
        unique_together = ("destination", "user")

    def __str__(self):
        return f"{self.destination.name} - {self.value}*"


class Favorite(TimeStampedModel):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="favorites")
    destination = models.ForeignKey(Destination, on_delete=models.CASCADE, related_name="favorited_by")

    class Meta:
        unique_together = ("user", "destination")
        ordering = ["-created_at"]


class VisitHistory(models.Model):
    """Tracks destinations a user has viewed/visited."""

    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="history")
    destination = models.ForeignKey(Destination, on_delete=models.CASCADE, related_name="visit_history")
    viewed_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-viewed_at"]
        verbose_name_plural = "Visit history"


class Hotel(TimeStampedModel):
    """
    Accommodation options near a destination. Populated either from your
    dataset (see `import_hotels` management command) or from external APIs
    (Google Places / Foursquare) via `tourist/utils.py`.
    """
    phone = models.CharField(max_length=30, blank=True)

    class BookingStatus(models.TextChoices):
        AVAILABLE = "available", "Available"
        UNAVAILABLE = "unavailable", "Unavailable"
        UNKNOWN = "unknown", "Unknown"
    

    class Source(models.TextChoices):
        DATASET = "dataset", "Imported Dataset"
        GOOGLE_PLACES = "google_places", "Google Places"
        FOURSQUARE = "foursquare", "Foursquare"
        MANUAL = "manual", "Manually Added"

    destination = models.ForeignKey(Destination, on_delete=models.CASCADE, related_name="hotels")
    name = models.CharField(max_length=200)
    price_per_night = models.DecimalField(max_digits=8, decimal_places=2, null=True, blank=True)
    currency = models.CharField(max_length=10, default="USD")
    rating = models.DecimalField(max_digits=3, decimal_places=2, null=True, blank=True)
    booking_status = models.CharField(max_length=20, choices=BookingStatus.choices, default=BookingStatus.UNKNOWN)
    booking_url = models.URLField(blank=True, help_text="Link to book externally (e.g. Booking.com, Google)")
    cover_image = models.ImageField(upload_to="hotels/covers/", blank=True, null=True)
    external_image_url = models.URLField(
        blank=True,
        help_text="Used instead of cover_image for externally-hosted photos (Unsplash/Wikimedia/etc.)."
    )
    facilities = models.JSONField(
        default=list, blank=True,
        help_text='e.g. ["wifi", "breakfast", "parking", "pool", "ac"]'
    )
    address = models.CharField(max_length=255, blank=True)
    latitude = models.DecimalField(max_digits=9, decimal_places=6, null=True, blank=True)
    longitude = models.DecimalField(max_digits=9, decimal_places=6, null=True, blank=True)
    source = models.CharField(max_length=20, choices=Source.choices, default=Source.DATASET)

    class Meta:
        ordering = ["-rating", "name"]

    def __str__(self):
        return f"{self.name} ({self.get_booking_status_display()})";

class Hospital(models.Model):

    destination = models.ForeignKey(
        Destination,
        on_delete=models.CASCADE,
        related_name="hospitals"
    )

    name = models.CharField(max_length=200)

    address = models.CharField(max_length=300)

    phone = models.CharField(max_length=50)

    latitude = models.DecimalField(max_digits=9, decimal_places=6)

    longitude = models.DecimalField(max_digits=9, decimal_places=6)

    district = models.CharField(max_length=100)


    district = models.CharField(max_length=100)
class PoliceStation(models.Model):

    destination = models.ForeignKey(
        Destination,
        on_delete=models.CASCADE,
        related_name="police_stations"
    )

    name = models.CharField(max_length=200)

    address = models.CharField(max_length=300)

    phone = models.CharField(max_length=50)

    latitude = models.DecimalField(max_digits=9, decimal_places=6)

    longitude = models.DecimalField(max_digits=9, decimal_places=6)

class BudgetEstimation(models.Model):
    destination = models.OneToOneField(
        Destination,
        on_delete=models.CASCADE,
        related_name="budget_estimation"
    )

    district = models.CharField(max_length=100)

    province = models.CharField(max_length=100)

    transport_cost = models.DecimalField(max_digits=8, decimal_places=2)

    food_cost_per_day = models.DecimalField(max_digits=8, decimal_places=2)

    accommodation_per_night = models.DecimalField(max_digits=8, decimal_places=2)

    local_transport = models.DecimalField(max_digits=8, decimal_places=2)

    entry_fee = models.DecimalField(max_digits=8, decimal_places=2, default=0)

    estimated_daily_budget = models.DecimalField(max_digits=8, decimal_places=2)

    estimated_trip_budget = models.DecimalField(max_digits=8, decimal_places=2)


class Budget(TimeStampedModel):
    class ExpenseCategory(models.TextChoices):
        ACCOMMODATION = "accommodation", "Accommodation"
        FOOD = "food", "Food"
        TRANSPORT = "transport", "Transport"
        ACTIVITIES = "activities", "Activities"
        OTHER = "other", "Other"

    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="budgets")
    destination = models.ForeignKey(
        Destination, on_delete=models.SET_NULL, null=True, blank=True, related_name="budget_entries"
    )
    title = models.CharField(max_length=200)
    category = models.CharField(max_length=20, choices=ExpenseCategory.choices, default=ExpenseCategory.OTHER)
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    currency = models.CharField(max_length=10, default="NPR")
    date = models.DateField(default=timezone.now)
    notes = models.TextField(blank=True)

    class Meta:
        ordering = ["-date"]


# ---------------------------------------------------------------------------
# Alerts & Emergency Information
# ---------------------------------------------------------------------------
class Alert(TimeStampedModel):
    class AlertType(models.TextChoices):
        WEATHER = "weather", "Weather"
        FLOOD = "flood", "Flood"
        EARTHQUAKE = "earthquake", "Earthquake"
        LANDSLIDE = "landslide", "Landslide"
        HEALTH = "health", "Health"
        CRIME = "crime", "Crime"
        TRANSPORT = "transport", "Transport"
        OTHER = "other", "Other"

    class Severity(models.TextChoices):
        LOW = "low", "Low"
        MODERATE = "moderate", "Moderate"
        HIGH = "high", "High"
        CRITICAL = "critical", "Critical"

    alert_type = models.CharField(max_length=20, choices=AlertType.choices)
    title = models.CharField(max_length=200)
    description = models.TextField()
    severity = models.CharField(max_length=20, choices=Severity.choices, default=Severity.MODERATE)

    latitude = models.DecimalField(max_digits=9, decimal_places=6, null=True, blank=True)
    longitude = models.DecimalField(max_digits=9, decimal_places=6, null=True, blank=True)
    city = models.CharField(max_length=100, blank=True)
    country = models.CharField(max_length=100, blank=True)

    source = models.CharField(max_length=100, blank=True, help_text="e.g. OpenWeatherMap, Govt. Authority")
    is_active = models.BooleanField(default=True)
    starts_at = models.DateTimeField(default=timezone.now)
    ends_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ["-created_at"]
        indexes = [models.Index(fields=["latitude", "longitude"])]


class EmergencyContact(TimeStampedModel):
    class ContactType(models.TextChoices):
        POLICE = "police", "Police"
        HOSPITAL = "hospital", "Hospital"
        TOURISM_OFFICE = "tourism_office", "Tourism Office"
        FIRE_STATION = "fire_station", "Fire Station"
        AMBULANCE = "ambulance", "Ambulance"
        EMBASSY = "embassy", "Embassy"
        WARD_OFFICE = "ward_office", "Ward Office"
        WARD_MEMBER = "ward_member", "Local Ward Member"

    contact_type = models.CharField(max_length=20, choices=ContactType.choices)
    name = models.CharField(max_length=200)
    phone_number = PhoneNumberField()
    alternate_phone = PhoneNumberField(blank=True, null=True)
    address = models.CharField(max_length=255, blank=True)
    city = models.CharField(max_length=100, blank=True)
    country = models.CharField(max_length=100, blank=True)
    latitude = models.DecimalField(max_digits=9, decimal_places=6)
    longitude = models.DecimalField(max_digits=9, decimal_places=6)
    is_24_hours = models.BooleanField(default=True)

    # Only meaningful for WARD_OFFICE / WARD_MEMBER rows — local governance
    # contacts tied to a specific municipal ward.
    ward_number = models.PositiveIntegerField(null=True, blank=True, help_text="Local ward number (ward contacts only)")
    designation = models.CharField(
        max_length=100, blank=True,
        help_text="Role, e.g. 'Ward Chairperson', 'Ward Member - Female', 'Ward Secretary' (ward contacts only)",
    )

    class Meta:
        ordering = ["contact_type", "ward_number", "name"]
        indexes = [models.Index(fields=["latitude", "longitude"]), models.Index(fields=["ward_number"])]

    def __str__(self):
        if self.ward_number:
            return f"{self.get_contact_type_display()} (Ward {self.ward_number}) - {self.name}"
        return f"{self.get_contact_type_display()} - {self.name}"
class RiskAnalysis(models.Model):

    destination = models.OneToOneField(
        Destination,
        on_delete=models.CASCADE,
        related_name="risk_analysis"
    )

    accidents = models.IntegerField(default=0)

    landslide = models.IntegerField(default=0)

    avalanche = models.IntegerField(default=0)

    flood = models.IntegerField(default=0)

    earthquake_damage = models.IntegerField(default=0)

    hospital_count = models.IntegerField(default=0)

    police_count = models.IntegerField(default=0)

    fire_station_count = models.IntegerField(default=0)

    emergency_risk = models.FloatField()

    natural_disaster_risk = models.FloatField()

    tourism_risk_index = models.FloatField()

    risk_category = models.CharField(max_length=50)

# ---------------------------------------------------------------------------
# Notifications
# ---------------------------------------------------------------------------
class Notification(TimeStampedModel):
    class Channel(models.TextChoices):
        EMAIL = "email", "Email"
        SMS = "sms", "SMS"
        PUSH = "push", "Push"
        IN_APP = "in_app", "In-App"

    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="notifications")
    channel = models.CharField(max_length=10, choices=Channel.choices, default=Channel.IN_APP)
    title = models.CharField(max_length=200)
    message = models.TextField()
    is_read = models.BooleanField(default=False)
    is_sent = models.BooleanField(default=False)
    related_alert = models.ForeignKey(Alert, on_delete=models.SET_NULL, null=True, blank=True)

    class Meta:
        ordering = ["-created_at"]


class TrustedContact(models.Model):
    """
    A person a user has designated to receive safety alerts / shared trip
    access. Doesn't need their own account -- identified by email or
    phone, contacted directly when needed (SOS, trip share links).
    """
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="trusted_contacts")
    name = models.CharField(max_length=150)
    relationship = models.CharField(max_length=100, blank=True, help_text="e.g. 'Parent', 'Spouse', 'Friend'")
    email = models.EmailField(blank=True)
    phone_number = PhoneNumberField(blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return f"{self.name} ({self.relationship or 'contact'}) for {self.user}"


class SharedTrip(models.Model):
    """
    A live location share the user has explicitly turned on. The
    `share_token` is what a TrustedContact uses to view it -- no account
    needed on their end, just the (unguessable, revocable) link.
    """
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="shared_trips")
    share_token = models.UUIDField(default=uuid.uuid4, editable=False, unique=True)
    label = models.CharField(max_length=150, blank=True, help_text="e.g. 'Annapurna trek, Day 3'")
    is_active = models.BooleanField(default=True)
    started_at = models.DateTimeField(auto_now_add=True)
    expires_at = models.DateTimeField(help_text="Auto-expires -- a share link should never stay valid forever.")
    trusted_contacts = models.ManyToManyField(TrustedContact, related_name="shared_trips", blank=True)

    class Meta:
        ordering = ["-started_at"]

    def is_valid(self):
        return self.is_active and timezone.now() < self.expires_at

    def __str__(self):
        return f"{self.label or 'Trip'} ({self.user}) -- {'active' if self.is_valid() else 'expired/ended'}"


class LocationPing(models.Model):
    """
    One GPS position update during an active SharedTrip. Polling-based
    (the trusted contact's view re-fetches the latest ping every N
    seconds) rather than WebSocket push -- simpler to build correctly
    first; true real-time (Django Channels) is a bigger, separate
    addition if genuinely needed later.
    """
    trip = models.ForeignKey(SharedTrip, on_delete=models.CASCADE, related_name="pings")
    latitude = models.DecimalField(max_digits=9, decimal_places=6)
    longitude = models.DecimalField(max_digits=9, decimal_places=6)
    recorded_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-recorded_at"]


class SOSAlert(models.Model):
    """
    An emergency trigger during a trip (shared or not). Kept separate
    from SharedTrip so an SOS can be raised even with no active share
    (e.g. share it retroactively / the app auto-starts one) -- the trip
    FK is optional for that reason.
    """
    class Status(models.TextChoices):
        ACTIVE = "active", "Active"
        RESOLVED = "resolved", "Resolved"
        FALSE_ALARM = "false_alarm", "False Alarm"

    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="sos_alerts")
    trip = models.ForeignKey(SharedTrip, on_delete=models.SET_NULL, null=True, blank=True, related_name="sos_alerts")
    latitude = models.DecimalField(max_digits=9, decimal_places=6, null=True, blank=True)
    longitude = models.DecimalField(max_digits=9, decimal_places=6, null=True, blank=True)
    message = models.TextField(blank=True)
    status = models.CharField(max_length=20, choices=Status.choices, default=Status.ACTIVE)
    triggered_at = models.DateTimeField(auto_now_add=True)
    resolved_at = models.DateTimeField(null=True, blank=True)
    notified_contacts = models.ManyToManyField(TrustedContact, related_name="sos_alerts", blank=True)

    class Meta:
        ordering = ["-triggered_at"]

    def __str__(self):
        return f"SOS from {self.user} ({self.status})"


class DeviceToken(models.Model):
    """Push notification device tokens (FCM)."""

    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="device_tokens")
    token = models.CharField(max_length=255, unique=True)
    platform = models.CharField(
        max_length=10, choices=[("ios", "iOS"), ("android", "Android"), ("web", "Web")], default="web"
    )
    created_at = models.DateTimeField(auto_now_add=True)


# ---------------------------------------------------------------------------
# ML integration
# ---------------------------------------------------------------------------
class MLInsight(TimeStampedModel):
    """
    Stores results produced by the teammate's ML microservice — e.g. an
    image-authenticity/category check run on a newly submitted cover photo,
    or a personalized recommendation score. The ML service pushes these via
    the `/api/v1/ml/results/` webhook (see tourist/views_ml.py).
    """

    class InsightType(models.TextChoices):
        IMAGE_CLASSIFICATION = "image_classification", "Image Classification"
        RECOMMENDATION_SCORE = "recommendation_score", "Recommendation Score"
        CROWD_PREDICTION = "crowd_prediction", "Crowd Level Prediction"

    destination = models.ForeignKey(Destination, on_delete=models.CASCADE, related_name="ml_insights")
    insight_type = models.CharField(max_length=30, choices=InsightType.choices)
    label = models.CharField(max_length=100, blank=True, help_text="e.g. predicted category, crowd level")
    score = models.FloatField(null=True, blank=True, help_text="Confidence / relevance score, 0-1")
    raw_result = models.JSONField(default=dict, blank=True, help_text="Full payload returned by the ML service")

    class Meta:
        ordering = ["-created_at"]


# ---------------------------------------------------------------------------
# OpenStreetMap (Overpass API) data — persisted, not just live pass-through.
# See tourist/services/overpass.py for the sync functions that populate these.
# ---------------------------------------------------------------------------
class OSMEssentialService(TimeStampedModel):
    class Category(models.TextChoices):
        HOSPITAL = "hospital", "Hospital"
        CLINIC = "clinic", "Clinic"
        PHARMACY = "pharmacy", "Pharmacy"
        POLICE = "police", "Police"
        ARMED_FORCE = "armed_force", "Armed Force"
        FIRE_STATION = "fire_station", "Fire Station"
        BANK = "bank", "Bank"
        AMBULANCE = "ambulance", "Ambulance"
        MUNICIPALITY_OFFICE = "municipality_office", "Municipality Office"
        TOURISM_OFFICE = "tourism_office", "Tourism Information Office"

    osm_id = models.CharField(max_length=50, unique=True, help_text="OSM type/id, e.g. 'node/123456'")
    category = models.CharField(max_length=30, choices=Category.choices)
    name = models.CharField(max_length=255)
    phone = models.CharField(max_length=50, blank=True)
    latitude = models.DecimalField(max_digits=9, decimal_places=6)
    longitude = models.DecimalField(max_digits=9, decimal_places=6)
    address = models.CharField(max_length=255, blank=True)
    raw_tags = models.JSONField(default=dict, blank=True)

    class Meta:
        ordering = ["category", "name"]
        indexes = [models.Index(fields=["latitude", "longitude"]), models.Index(fields=["category"])]

    def __str__(self):
        return f"{self.get_category_display()} - {self.name}"


class OSMTourismPlace(TimeStampedModel):
    class Category(models.TextChoices):
        ATTRACTION = "attraction", "Attraction"
        VIEWPOINT = "viewpoint", "Viewpoint"
        MUSEUM = "museum", "Museum"
        HOTEL = "hotel", "Hotel"
        INFORMATION = "information", "Information"
        RESTAURANT = "restaurant", "Restaurant"
        CAFE = "cafe", "Cafe"
        MONUMENT = "monument", "Monument"
        PEAK = "peak", "Natural Peak"
        WATERFALL = "waterfall", "Waterfall"
        HIKING_PATH = "hiking_path", "Hiking Path"
        HIKING_ROUTE = "hiking_route", "Hiking Route"

    osm_id = models.CharField(max_length=50, unique=True, help_text="OSM type/id, e.g. 'way/123456'")
    category = models.CharField(max_length=30, choices=Category.choices)
    name = models.CharField(max_length=255)
    latitude = models.DecimalField(max_digits=9, decimal_places=6)
    longitude = models.DecimalField(max_digits=9, decimal_places=6)
    address = models.CharField(max_length=255, blank=True)
    raw_tags = models.JSONField(default=dict, blank=True)

    class Meta:
        ordering = ["category", "name"]
        indexes = [models.Index(fields=["latitude", "longitude"]), models.Index(fields=["category"])]

    def __str__(self):
        return f"{self.get_category_display()} - {self.name}"


class DestinationAuditLog(TimeStampedModel):
    """
    One row per moderation action on a Destination -- submitted, approved,
    rejected, archived, edited. Tracks who did what and when.
    """
    class Action(models.TextChoices):
        SUBMITTED = "submitted", "Submitted"
        APPROVED = "approved", "Approved"
        REJECTED = "rejected", "Rejected"
        ARCHIVED = "archived", "Archived"
        EDITED = "edited", "Edited"

    destination = models.ForeignKey(
        "Destination", on_delete=models.CASCADE, related_name="audit_log"
    )
    action = models.CharField(max_length=20, choices=Action.choices)
    actor = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True,
        help_text="Who performed this action (null for system-generated entries)."
    )
    note = models.TextField(blank=True)
    previous_status = models.CharField(max_length=20, blank=True)
    new_status = models.CharField(max_length=20, blank=True)

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return f"{self.destination.name}: {self.action} by {self.actor or 'system'}"


# ---------------------------------------------------------------------------
# ML-Connected Traveler & Field Staff Feedback (Expenses & Risk)
# ---------------------------------------------------------------------------
class TravelExpenseFeedback(TimeStampedModel):
    """
    Field / traveler real expenditure records. Connects directly to the
    ML budget estimation engine so subsequent calculations learn from
    actual ground spending.
    """
    user = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True,
        related_name="expense_submissions"
    )
    destination = models.ForeignKey(
        Destination, on_delete=models.SET_NULL, null=True, blank=True,
        related_name="expense_feedbacks"
    )
    destination_name = models.CharField(max_length=200)
    num_people = models.PositiveIntegerField(default=1)
    num_days = models.PositiveIntegerField(default=1)
    travel_mode = models.CharField(max_length=100, default="Tourist Bus")
    accommodation_cost = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    travel_cost = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    entry_cost = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    food_cost = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    extra_cost = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    total_cost = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    route_details = models.TextField(blank=True, help_text="Practical route or transit details taken")
    is_employee_verified = models.BooleanField(default=False)
    notes = models.TextField(blank=True)

    class Meta:
        ordering = ["-created_at"]

    def save(self, *args, **kwargs):
        if not self.total_cost or self.total_cost == 0:
            self.total_cost = (
                (self.accommodation_cost or 0) +
                (self.travel_cost or 0) +
                (self.entry_cost or 0) +
                (self.food_cost or 0) +
                (self.extra_cost or 0)
            )
        super().save(*args, **kwargs)

    def __str__(self):
        return f"{self.destination_name} - {self.total_cost} NPR ({self.num_days} days, {self.num_people} ppl)"


class TravelRiskFeedback(TimeStampedModel):
    """
    Detailed traveler risk & safety feedback: altitude sickness, hazards,
    transport ease, helpfulness of locals, greeting/hospitality rating.
    Connects to ML Risk scoring and real-time safety index calculations.
    """
    user = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True,
        related_name="risk_submissions"
    )
    destination = models.ForeignKey(
        Destination, on_delete=models.SET_NULL, null=True, blank=True,
        related_name="risk_feedbacks"
    )
    destination_name = models.CharField(max_length=200)
    became_sick = models.BooleanField(default=False)
    sickness_type = models.CharField(
        max_length=100, blank=True,
        help_text="e.g. Altitude Sickness (AMS), Food Poisoning, Dehydration, Cold/Hypothermia"
    )
    misleading_activities = models.BooleanField(default=False)
    misleading_details = models.TextField(blank=True)
    accident_occurred = models.BooleanField(default=False)
    accident_details = models.TextField(blank=True)
    hazard_witnessed = models.CharField(
        max_length=100, blank=True, default="None",
        help_text="e.g. Landslide, Avalanche, Flood, Heavy Snow, Rockfall, None"
    )
    transport_accessibility_rating = models.PositiveSmallIntegerField(
        default=4, help_text="1 (Hard to reach / 4WD only) to 5 (Direct highway / flight)"
    )
    people_helpfulness_rating = models.PositiveSmallIntegerField(
        default=5, help_text="1 (Unhelpful) to 5 (Extremely friendly & helpful)"
    )
    greeting_behavior_rating = models.PositiveSmallIntegerField(
        default=5, help_text="1 (Hostile) to 5 (Very warm & respectful)"
    )
    overall_safety_rating = models.FloatField(default=9.0, help_text="Safety score from 1.0 to 10.0")
    comments = models.TextField(blank=True)

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return f"{self.destination_name} safety report - {self.overall_safety_rating}/10"
