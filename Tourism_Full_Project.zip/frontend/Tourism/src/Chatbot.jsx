import { useState, useRef, useEffect } from "react"
import { FiSend, FiCompass, FiShield, FiDollarSign, FiPhoneCall, FiSun, FiMapPin } from "react-icons/fi"
import chatbotApi from "./api/chatbotApi"
import useGeolocation from "./hooks/useGeolocation"

const QUICK_PROMPTS = [
  { icon: FiCompass, text: "Top places to visit in Nepal" },
  { icon: FiDollarSign, text: "Estimated budget for 7 days trip" },
  { icon: FiShield, text: "Trekking safety & permits guide" },
  { icon: FiPhoneCall, text: "Nepal tourist emergency numbers" },
  { icon: FiSun, text: "Best time of year to visit" },
]

const ChatBot = () => {
  const [messages, setMessages] = useState([
    {
      role: "assistant",
      content:
        "Namaste! 🙏 Welcome to Himal AI.\n\nI'm your official AI Travel Guide for Nepal. Ask me anything about destinations, trekking routes, budgets, accommodation, weather forecasts, emergency services, or local cultural tips.",
    },
  ])

  const [input, setInput] = useState("")
  const [sending, setSending] = useState(false)
  const [conversationId, setConversationId] = useState(null)

  const { position } = useGeolocation()
  const chatBoxRef = useRef(null)

  useEffect(() => {
    if (chatBoxRef.current) {
      chatBoxRef.current.scrollTop = chatBoxRef.current.scrollHeight
    }
  }, [messages])

  const handleSend = async (textToSend = null) => {
    const query = typeof textToSend === "string" ? textToSend : input.trim()
    if (!query || sending) return

    const userMessage = {
      role: "user",
      content: query,
    }

    setMessages((prev) => [...prev, userMessage])
    setInput("")
    setSending(true)

    try {
      const { data } = await chatbotApi.sendMessage(
        query,
        position?.lat,
        position?.lng,
        conversationId
      )

      if (data.conversation_id) {
        setConversationId(data.conversation_id)
      }

      setMessages((prev) => [
        ...prev,
        {
          role: "assistant",
          content:
            data.reply ||
            "I'm here to help with all Nepal destinations and travel plans!",
        },
      ])
    } catch (error) {
      console.error(error)
      const errorMessage =
        error?.response?.data?.detail ||
        error?.response?.data?.reply ||
        "I can help you with Nepal destinations, budgets, hotels, and emergency contacts. Please ask a question!"

      setMessages((prev) => [
        ...prev,
        {
          role: "assistant",
          content: errorMessage,
        },
      ])
    } finally {
      setSending(false)
    }
  }

  const handleKeyDown = (e) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault()
      handleSend()
    }
  }

  return (
    <div className="container-app py-8">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-6">
          <h1 className="text-3xl font-extrabold text-gray-900 flex items-center justify-center gap-2">
            🏔️ Himal AI Assistant
          </h1>
          <p className="text-gray-500 text-sm mt-1">
            Intelligent Travel Guide • All 77 Districts • Budgeting • Road & Trek Routes • Emergency Hub
          </p>
        </div>

        {/* Quick prompt badges */}
        <div className="flex flex-wrap items-center justify-center gap-2 mb-6">
          {QUICK_PROMPTS.map((qp, idx) => {
            const Icon = qp.icon
            return (
              <button
                key={idx}
                onClick={() => handleSend(qp.text)}
                disabled={sending}
                className="text-xs font-medium bg-purple-50 text-purple-700 hover:bg-purple-100 hover:text-purple-800 border border-purple-200/60 rounded-full px-3 py-1.5 flex items-center gap-1.5 transition-all shadow-sm"
              >
                <Icon size={12} />
                {qp.text}
              </button>
            )
          })}
        </div>

        <div className="card-base h-[620px] flex flex-col overflow-hidden border border-purple-100 shadow-xl rounded-2xl">
          <div className="bg-gradient-to-r from-purple-800 via-purple-700 to-rose-700 text-white px-6 py-4 flex items-center justify-between shadow-md">
            <div>
              <h2 className="font-bold text-lg flex items-center gap-2">
                Himal AI Travel Companion 🙏
              </h2>
              <p className="text-xs text-purple-100">
                Connected to Nepal Tourism Knowledge Engine & Live GPS
              </p>
            </div>
            {position && (
              <span className="text-xs bg-white/20 px-2.5 py-1 rounded-full flex items-center gap-1">
                <FiMapPin size={12} /> GPS Active
              </span>
            )}
          </div>

          <div
            ref={chatBoxRef}
            className="flex-1 overflow-y-auto p-5 space-y-4 bg-gray-50/70"
          >
            {messages.map((message, index) => (
              <div
                key={index}
                className={`flex ${
                  message.role === "user" ? "justify-end" : "justify-start"
                }`}
              >
                <div
                  className={`max-w-[82%] rounded-2xl px-5 py-3.5 whitespace-pre-wrap text-sm leading-relaxed shadow-sm ${
                    message.role === "user"
                      ? "bg-purple-700 text-white rounded-br-none"
                      : "bg-white text-gray-800 border border-gray-100 rounded-bl-none shadow"
                  }`}
                >
                  {message.content}
                </div>
              </div>
            ))}

            {sending && (
              <div className="flex items-center gap-2 text-xs text-purple-600 font-medium italic">
                <span className="w-2 h-2 rounded-full bg-purple-500 animate-pulse"></span>
                Himal AI is researching and typing...
              </div>
            )}
          </div>

          <form
            onSubmit={(e) => {
              e.preventDefault()
              handleSend()
            }}
            className="border-t p-4 flex gap-3 bg-white"
          >
            <textarea
              rows={2}
              value={input}
              disabled={sending}
              placeholder="Ask anything about travelling in Nepal..."
              className="input-field flex-1 resize-none text-sm"
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={handleKeyDown}
            />

            <button
              type="submit"
              disabled={sending || !input.trim()}
              className="btn-primary px-6 flex items-center justify-center bg-purple-700 hover:bg-purple-800 transition-colors disabled:opacity-50"
            >
              <FiSend size={18} />
            </button>
          </form>
        </div>
      </div>
    </div>
  )
}

export default ChatBot
