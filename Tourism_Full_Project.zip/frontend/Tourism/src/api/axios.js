import axios from "axios"


const api = axios.create({

    baseURL:
        import.meta.env.VITE_API_BASE_URL ||
        "/api/v1",

    headers: {
        "Content-Type": "application/json",
    },

})



// Attach JWT token automatically
api.interceptors.request.use(

    (config) => {

        const token = localStorage.getItem("access")


        if (token) {

            config.headers.Authorization =
                `Bearer ${token}`

        }


        return config

    },


    (error) =>
        Promise.reject(error)

)



export default api