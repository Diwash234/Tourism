import React from "react";
import { motion } from "framer-motion";
import {
  FiCheckCircle,
  FiXCircle,
  FiInfo,
  FiAlertTriangle,
} from "react-icons/fi";


const icons = {
  success: (
    <FiCheckCircle
      className="text-forest-500"
      size={20}
    />
  ),

  error: (
    <FiXCircle
      className="text-nepalred-500"
      size={20}
    />
  ),

  warning: (
    <FiAlertTriangle
      className="text-saffron-500"
      size={20}
    />
  ),

  info: (
    <FiInfo
      className="text-himalaya-500"
      size={20}
    />
  ),
};


const Toast = ({ message, type = "info" }) => {

  return (

    <motion.div
      initial={{
        opacity: 0,
        x: 50,
      }}

      animate={{
        opacity: 1,
        x: 0,
      }}

      exit={{
        opacity: 0,
        x: 50,
      }}

      className="
        flex
        items-center
        gap-3
        bg-white
        shadow-hover
        rounded-xl
        px-4
        py-3
        min-w-[260px]
        border
        border-gray-100
      "
    >

      {icons[type] || icons.info}


      <span className="text-sm text-dark">
        {message}
      </span>


    </motion.div>

  );
};


export default Toast;