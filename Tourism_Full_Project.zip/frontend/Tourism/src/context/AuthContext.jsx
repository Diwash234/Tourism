import authApi from "../api/authApi"
import React, { createContext, useState, useEffect } from "react";
export const AuthContext = createContext(null)

export const AuthProvider = ({ children }) => {

  const [user, setUser] = useState(() => {
    const stored = localStorage.getItem("user")

    try {
      return stored ? JSON.parse(stored) : null
    } catch {
      return null
    }
  })

  const [loading, setLoading] = useState(true)


  useEffect(() => {

    const token = localStorage.getItem("access")

    if (!token) {
      setLoading(false)
      return
    }


    authApi
      .getCurrentUser()
      .then(({ data }) => {

        setUser(data)

        localStorage.setItem(
          "user",
          JSON.stringify(data)
        )

      })
      .catch(() => {

        setUser(null)

        localStorage.removeItem("access")
        localStorage.removeItem("refresh")
        localStorage.removeItem("user")

      })
      .finally(() => {

        setLoading(false)

      })

  }, [])



  const login = async (credentials) => {

    const { data } = await authApi.login(credentials)


    // Save JWT tokens from Django SimpleJWT
    localStorage.setItem(
      "access",
      data.access
    )

    localStorage.setItem(
      "refresh",
      data.refresh
    )


    /*
      If your login API returns user data,
      save it.
      Otherwise fetch current user from profile API.
    */

    let userData = data.user


    if (!userData) {

      const response = await authApi.getCurrentUser()

      userData = response.data

    }


    localStorage.setItem(
      "user",
      JSON.stringify(userData)
    )


    setUser(userData)


    return userData
  }


  // NEW: Google/GitHub OAuth callbacks return {access, refresh, user}
  // directly (see authApi.js/views_oauth.py) — same JWT pair shape as
  // login(), just not obtained via the email/password endpoint. Reuses
  // the exact same storage steps rather than duplicating them.
  const loginWithTokens = async (data) => {
    localStorage.setItem("access", data.access)
    localStorage.setItem("refresh", data.refresh)

    let userData = data.user
    if (!userData) {
      const response = await authApi.getCurrentUser()
      userData = response.data
    }

    localStorage.setItem("user", JSON.stringify(userData))
    setUser(userData)
    return userData
  }



  const register = async (payload) => {

    const { data } = await authApi.register(payload)

    return data

  }



  const logout = async () => {

    try {

      await authApi.logout()

    } catch (error) {

      console.log("Logout error:", error)

    }


    localStorage.removeItem("access")
    localStorage.removeItem("refresh")
    localStorage.removeItem("user")


    setUser(null)

  }



  const isAuthenticated = !!user

  // FIX: role check was `=== "admin"` only, which locked out super_admin
  // and tourism_admin accounts (backend permission hierarchy in
  // tourist/permissions.py treats all three as admin tiers). Also honor
  // is_staff/is_superuser when the backend exposes them.
  const ADMIN_ROLES = ["admin", "super_admin", "tourism_admin"]
  const isAdmin =
    (user && ADMIN_ROLES.includes(user.role)) ||
    user?.is_staff === true ||
    user?.is_superuser === true



  return (

    <AuthContext.Provider
      value={{
        user,
        setUser,
        login,
        loginWithTokens,
        register,
        logout,
        isAuthenticated,
        isAdmin,
        loading,
      }}
    >

      {children}

    </AuthContext.Provider>

  )
}