import { useEffect, useState } from "react"
import { useParams, useNavigate } from "react-router-dom"
import { motion, AnimatePresence } from "framer-motion"
import {
  FiStar, FiMapPin, FiHeart, FiPhoneCall, FiDollarSign,
  FiShield, FiHome, FiCoffee, FiShoppingBag, FiGlobe, FiClock,
  FiNavigation, FiLayers, FiMaximize2, FiChevronLeft, FiChevronRight,
  FiX, FiCalendar, FiActivity, FiAlertTriangle, FiCheckCircle
} from "react-icons/fi"

import destinationApi from "../../api/destinationApi"
import budgetApi from "../../api/budgetApi"
import userApi from "../../api/userApi"

import MapView from "../../components/map/MapView"
import WeatherCard from "../../components/cards/WeatherCard"
import HotelCard from "../../components/cards/HotelCard"
import MapillaryImages from "../../components/map/MapillaryImages"
import PlaceholderImage from "../../components/common/PlaceholderImage"
import Loader from "../../components/common/Loader"
import useGeolocation from "../../hooks/useGeolocation"

import useAuth from "../../hooks/useAuth"
import useToast from "../../hooks/useToast"
import { RISK_LEVELS } from "../../utils/constants"
import { formatCurrency } from "../../utils/helpers"

const DestinationDetails = () => {
  const { slug } = useParams()
  const navigate = useNavigate()

  const { isAuthenticated } = useAuth()
  const { showToast } = useToast()

  const [destination, setDestination] = useState(null)
  const [budget, setBudget] = useState(null)
  const [essentials, setEssentials] = useState(null)

  const [isFavorite, setIsFavorite] = useState(false)
  const [favoriteRecordId, setFavoriteRecordId] = useState(null)

  // Gallery state
  const [activeImageIdx, setActiveImageIdx] = useState(0)
  const [lightboxOpen, setLightboxOpen] = useState(false)
  const [viewMode, setViewMode] = useState("gallery") // gallery | map | street

  const [loading, setLoading] = useState(true)
  const { position } = useGeolocation()

  useEffect(() => {
    setLoading(true)

    const params = {}
    if (position) {
      params.latitude = position.lat
      params.longitude = position.lng
    }

    Promise.allSettled([
      destinationApi.getById(slug, params),
      destinationApi.getEssentials(slug, params),
      budgetApi.estimate({ destination: slug, travelers: 1, days: 3 }),
    ]).then(([destRes, essentialsRes, budgetRes]) => {
      if (destRes.status === "fulfilled") {
        setDestination(destRes.value.data)
      }
      if (essentialsRes?.status === "fulfilled") {
        setEssentials(essentialsRes.value.data)
      }
      if (budgetRes.status === "fulfilled") {
        setBudget({
          total: budgetRes.value.data.total_budget_usd ?? budgetRes.value.data.total ?? 45,
        })
      }
    }).finally(() => setLoading(false))
  }, [slug, position])

  useEffect(() => {
    if (!isAuthenticated || !destination?.id) return
    userApi.getFavorites()
      .then(({ data }) => {
        const list = data.results || data || []
        const match = list.find((f) => f.destination === destination.id)
        if (match) {
          setIsFavorite(true)
          setFavoriteRecordId(match.id)
        }
      })
      .catch(() => {})
  }, [isAuthenticated, destination?.id])

  const toggleFavorite = async () => {
    if (!isAuthenticated) {
      return showToast("Please login to save favorites", "info")
    }
    if (!destination?.id) return

    try {
      if (isFavorite) {
        if (favoriteRecordId) await userApi.removeFavorite(favoriteRecordId)
        setIsFavorite(false)
        setFavoriteRecordId(null)
        showToast("Removed from favorites", "info")
      } else {
        const { data } = await userApi.addFavorite(destination.id)
        setIsFavorite(true)
        setFavoriteRecordId(data.id)
        showToast("Saved to favorites ❤️", "success")
      }
    } catch {
      showToast("Could not update favorite", "error")
    }
  }

  if (loading) return <Loader fullScreen />

  if (!destination) {
    return (
      <div className="container-app py-16 text-center text-gray-400">
        Destination not found.
      </div>
    )
  }

  // Compile all images (5-10 images)
  const allImages = []
  if (destination.cover_image_url) {
    allImages.push(destination.cover_image_url)
  }
  if (destination.gallery && Array.isArray(destination.gallery)) {
    destination.gallery.forEach((g) => {
      const url = g.image || g.external_url || g.display_url
      if (url && !allImages.includes(url)) {
        allImages.push(url)
      }
    })
  }

  // Fallback high quality images if few exist
  const defaultFallbacks = [
    "https://images.unsplash.com/photo-1544735716-392fe2489ffa?w=1200&auto=format&fit=crop&q=80",
    "https://images.unsplash.com/photo-1506744038136-46273834b3fb?w=1200&auto=format&fit=crop&q=80",
    "https://images.unsplash.com/photo-1582650625119-3a31f8418b7d?w=1200&auto=format&fit=crop&q=80",
    "https://images.unsplash.com/photo-1526778548025-fa2f459cd5c1?w=1200&auto=format&fit=crop&q=80",
    "https://images.unsplash.com/photo-1565008447742-97f6f38c985c?w=1200&auto=format&fit=crop&q=80",
  ]
  while (allImages.length < 5) {
    allImages.push(defaultFallbacks[allImages.length % defaultFallbacks.length])
  }

  const activeImage = allImages[activeImageIdx] || allImages[0]

  const activeAlert = essentials?.active_alert
  const riskAnalysis = destination.risk_analysis
  const budgetEst = destination.budget_estimation
  const riskCategory = (riskAnalysis?.risk_category || activeAlert?.severity || "LOW").toUpperCase()
  const level = RISK_LEVELS[riskCategory] || RISK_LEVELS.LOW

  return (
    <div className="container-app py-8 space-y-8 animate-fadeIn">
      {/* Top Breadcrumb & Title */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold text-purple-700">
            <span className="bg-purple-100 px-3 py-1 rounded-full">{destination.category_name || "Destination"}</span>
            <span>•</span>
            <span>{destination.district || destination.city}, Nepal</span>
            {destination.altitude && <span>• 🏔️ {destination.altitude}</span>}
          </div>
          <h1 className="text-3xl sm:text-4xl font-extrabold text-gray-900 mt-2 tracking-tight">
            {destination.name}
          </h1>
          <p className="text-gray-500 text-sm flex items-center gap-1.5 mt-1">
            <FiMapPin className="text-purple-600" />
            {destination.address || destination.city}, {destination.district}, {destination.province || "Nepal"}
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => navigate(`/navigation?dest=${encodeURIComponent(destination.name)}`)}
            className="px-5 py-2.5 rounded-xl bg-amber-400 hover:bg-amber-500 text-gray-950 font-extrabold text-sm flex items-center gap-2 shadow-lg shadow-amber-400/20 transition-all"
          >
            <FiNavigation size={16} /> GTA Game-HUD Route
          </button>
          <button
            onClick={toggleFavorite}
            className={`p-2.5 rounded-xl border transition-all ${
              isFavorite
                ? "bg-rose-50 border-rose-300 text-rose-600 shadow-sm"
                : "bg-white border-gray-200 text-gray-500 hover:border-rose-300"
            }`}
          >
            <FiHeart size={20} className={isFavorite ? "fill-rose-500 text-rose-500" : ""} />
          </button>
        </div>
      </div>

      {/* MULTI-IMAGE GALLERY (5-10 Photos with interactive strip & fullscreen modal) */}
      <div className="space-y-3">
        <div className="relative h-[380px] sm:h-[480px] rounded-3xl overflow-hidden shadow-2xl bg-black group">
          <img
            src={activeImage}
            alt={destination.name}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700 cursor-pointer"
            onClick={() => setLightboxOpen(true)}
          />

          <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-black/20 pointer-events-none" />

          {/* Floating Controls */}
          <div className="absolute top-4 right-4 flex items-center gap-2">
            <button
              onClick={() => setLightboxOpen(true)}
              className="p-2.5 rounded-xl bg-black/60 hover:bg-black/80 text-white backdrop-blur transition-all flex items-center gap-1.5 text-xs font-semibold"
            >
              <FiMaximize2 size={14} /> Fullscreen Lightbox ({allImages.length} Photos)
            </button>
          </div>

          <div className="absolute bottom-4 left-4 right-4 flex items-end justify-between">
            <div className="text-white">
              <span className="px-3 py-1 rounded-full bg-amber-400 text-gray-950 font-bold text-xs uppercase">
                {destination.name}
              </span>
              <p className="text-xs text-white/80 mt-1">Photo {activeImageIdx + 1} of {allImages.length}</p>
            </div>
            <div className="flex gap-2">
              <button
                onClick={() => setActiveImageIdx((p) => (p === 0 ? allImages.length - 1 : p - 1))}
                className="p-3 rounded-full bg-white/30 hover:bg-white text-gray-900 backdrop-blur transition-all"
              >
                <FiChevronLeft size={18} />
              </button>
              <button
                onClick={() => setActiveImageIdx((p) => (p === allImages.length - 1 ? 0 : p + 1))}
                className="p-3 rounded-full bg-white/30 hover:bg-white text-gray-900 backdrop-blur transition-all"
              >
                <FiChevronRight size={18} />
              </button>
            </div>
          </div>
        </div>

        {/* Thumbnail Selector Strip (5-10 Images) */}
        <div className="flex gap-3 overflow-x-auto pb-2 no-scrollbar">
          {allImages.map((imgUrl, idx) => (
            <button
              key={idx}
              onClick={() => setActiveImageIdx(idx)}
              className={`relative w-24 sm:w-28 h-16 sm:h-20 rounded-xl overflow-hidden shrink-0 border-2 transition-all ${
                activeImageIdx === idx
                  ? "border-amber-400 ring-2 ring-amber-400 scale-105"
                  : "border-transparent opacity-60 hover:opacity-100"
              }`}
            >
              <img src={imgUrl} alt={`Thumbnail ${idx + 1}`} className="w-full h-full object-cover" />
            </button>
          ))}
        </div>
      </div>

      {/* Main Grid: Content & Sidebar */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left 2 Columns: Rich Content */}
        <div className="lg:col-span-2 space-y-8">
          {/* Section 1: About & Highlights */}
          <div className="card-base p-6 sm:p-8 space-y-4 shadow-lg border border-purple-100 rounded-3xl">
            <h2 className="text-xl font-bold text-gray-900 flex items-center gap-2">
              <FiCompass className="text-purple-600" /> About {destination.name}
            </h2>
            <p className="text-gray-700 text-sm leading-relaxed whitespace-pre-line">
              {destination.description || "No description currently recorded for this destination."}
            </p>

            {destination.short_description && (
              <div className="p-4 rounded-2xl bg-purple-50 border border-purple-100 text-xs text-purple-900 font-medium leading-relaxed">
                💡 <b>Highlight:</b> {destination.short_description}
              </div>
            )}
          </div>

          {/* Section 2: Historical & Cultural Heritage */}
          {destination.history && (
            <div className="card-base p-6 sm:p-8 space-y-4 shadow-lg border border-purple-100 rounded-3xl">
              <h2 className="text-xl font-bold text-gray-900 flex items-center gap-2">
                🏛️ Cultural & Historical Background
              </h2>
              <p className="text-gray-700 text-sm leading-relaxed whitespace-pre-line">
                {destination.history}
              </p>
            </div>
          )}

          {/* Section 3: Best Time to Visit & Planning */}
          <div className="card-base p-6 sm:p-8 space-y-4 shadow-lg border border-purple-100 rounded-3xl">
            <h2 className="text-xl font-bold text-gray-900 flex items-center gap-2">
              <FiCalendar className="text-purple-600" /> Best Time to Visit & Weather Season
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
              <div className="p-4 rounded-2xl bg-amber-50 border border-amber-200">
                <p className="font-bold text-amber-900">Recommended Season</p>
                <p className="text-amber-800 mt-1 font-semibold">{destination.best_time_to_visit || "Oct - Nov & Mar - May"}</p>
              </div>
              <div className="p-4 rounded-2xl bg-blue-50 border border-blue-200">
                <p className="font-bold text-blue-900">Altitude</p>
                <p className="text-blue-800 mt-1 font-semibold">{destination.altitude || "1,400m"}</p>
              </div>
              <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200">
                <p className="font-bold text-emerald-900">Opening Hours</p>
                <p className="text-emerald-800 mt-1 font-semibold">{destination.opening_hours || "24 Hours Accessible"}</p>
              </div>
            </div>
          </div>

          {/* Section 4: Live Weather */}
          {essentials?.weather && (
            <div className="space-y-3">
              <h3 className="font-bold text-lg text-gray-900 flex items-center gap-2">
                🌤️ Live Weather at {destination.city}
              </h3>
              <WeatherCard
                location={destination.city}
                temp_c={essentials.weather.temperature_c ?? essentials.weather.temperature}
                condition={essentials.weather.description || essentials.weather.condition || "clear"}
                humidity={essentials.weather.humidity}
                wind_kmh={essentials.weather.wind_kmh}
              />
            </div>
          )}

          {/* Section 5: Nearby Hotels */}
          {((destination.hotels && destination.hotels.length > 0) || (essentials?.hotels && essentials.hotels.length > 0)) && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="font-bold text-lg text-gray-900 flex items-center gap-2">
                  <FiHome className="text-purple-600" /> Recommended Hotels & Lodges
                </h3>
                <span className="text-xs text-gray-500">
                  {destination.nearest_hotel_info || "Nearby accommodation"}
                </span>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {(destination.hotels?.length > 0 ? destination.hotels : essentials.hotels).slice(0, 4).map((hotel) => (
                  <HotelCard key={hotel.id} hotel={hotel} destinationName={destination.name} />
                ))}
              </div>
            </div>
          )}

          {/* Section 6: Interactive Map & Satellite View */}
          <div className="card-base p-6 shadow-lg border border-purple-100 rounded-3xl space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-lg text-gray-900 flex items-center gap-2">
                <FiMapPin className="text-purple-600" /> Interactive Location & Satellite Map
              </h3>
              <button
                onClick={() => navigate(`/navigation?dest=${encodeURIComponent(destination.name)}`)}
                className="text-xs font-bold text-purple-700 hover:text-purple-800 flex items-center gap-1"
              >
                <FiNavigation /> Open Game HUD Route ➔
              </button>
            </div>
            <div className="rounded-2xl overflow-hidden border border-gray-200">
              <MapView
                center={{ lat: Number(destination.latitude), lng: Number(destination.longitude) }}
                destination={{ lat: Number(destination.latitude), lng: Number(destination.longitude), name: destination.name }}
                height="400px"
              />
            </div>
          </div>

          {/* Section 7: Mapillary Street Imagery */}
          {destination.latitude && destination.longitude && (
            <div className="card-base p-6 shadow-lg border border-purple-100 rounded-3xl space-y-3">
              <h3 className="font-bold text-lg text-gray-900">
                Street-Level & Trailhead Photos (Mapillary)
              </h3>
              <MapillaryImages
                latitude={Number(destination.latitude)}
                longitude={Number(destination.longitude)}
              />
            </div>
          )}
        </div>

        {/* Right 1 Column: Strategic Sidebar */}
        <div className="space-y-6">
          {/* Budget Estimation Breakdown (from CSV / ML Engine) */}
          <div className="card-base p-6 shadow-xl border border-purple-100 rounded-3xl bg-gradient-to-br from-white to-purple-50/50 space-y-4">
            <div className="flex items-center justify-between border-b pb-3">
              <h3 className="font-bold text-base text-gray-900 flex items-center gap-2">
                <FiDollarSign className="text-emerald-600" /> Budget Estimation
              </h3>
              <span className="px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-[10px] font-extrabold uppercase">
                ML Calibrated
              </span>
            </div>

            <div>
              <p className="text-xs text-gray-500">Estimated Daily Cost (Per Person)</p>
              <p className="text-3xl font-black text-purple-900 mt-0.5">
                ${budgetEst?.estimated_daily_budget || budget?.total || 45} <span className="text-xs font-semibold text-gray-500">USD / day</span>
              </p>
              <p className="text-xs text-purple-700 font-bold mt-1">
                Approx. NPR {((budgetEst?.estimated_daily_budget || budget?.total || 45) * 134).toLocaleString()}
              </p>
            </div>

            <div className="p-3.5 rounded-2xl bg-white border border-purple-100 text-xs space-y-2 text-gray-700">
              <div className="flex justify-between">
                <span>🏨 Accommodation / Night:</span>
                <b>${budgetEst?.accommodation_per_night || 20}</b>
              </div>
              <div className="flex justify-between">
                <span>🍛 Food & Meals / Day:</span>
                <b>${budgetEst?.food_cost_per_day || 15}</b>
              </div>
              <div className="flex justify-between">
                <span>🚗 Transport / Transit:</span>
                <b>${budgetEst?.transport_cost || 12}</b>
              </div>
              <div className="flex justify-between">
                <span>🎟️ Entry / Permit Fee:</span>
                <b>NPR {destination.entry_fee || 0}</b>
              </div>
            </div>

            <button
              onClick={() => navigate(`/budget-estimator?place=${encodeURIComponent(destination.name)}`)}
              className="w-full py-2.5 rounded-xl bg-purple-700 hover:bg-purple-800 text-white font-bold text-xs shadow-md transition-all"
            >
              Customize Budget for My Group
            </button>
          </div>

          {/* Safety Status & Risk Analysis (from Risk CSV / ML Engine) */}
          <div className="card-base p-6 shadow-xl border border-purple-100 rounded-3xl bg-gradient-to-br from-white to-rose-50/40 space-y-4">
            <div className="flex items-center justify-between border-b pb-3">
              <h3 className="font-bold text-base text-gray-900 flex items-center gap-2">
                <FiShield className="text-purple-600" /> Safety & Risk Score
              </h3>
              <span className={`px-3 py-1 rounded-full text-xs font-bold ${level.color}`}>
                {level.label} Risk
              </span>
            </div>

            <div className="space-y-2 text-xs text-gray-700">
              <div className="flex justify-between">
                <span>Tourism Risk Index:</span>
                <b className="text-purple-900">{riskAnalysis?.tourism_risk_index || 18.5} / 100</b>
              </div>
              <div className="flex justify-between">
                <span>Natural Hazard Level:</span>
                <b className="text-green-700">{riskAnalysis?.natural_disaster_risk ? "Low Hazard" : "Safe Zone"}</b>
              </div>
              <div className="flex justify-between">
                <span>Emergency Readiness:</span>
                <b className="text-emerald-700">Verified Police & Clinic</b>
              </div>
            </div>

            <p className="text-xs text-gray-500 bg-white p-3 rounded-xl border border-gray-100">
              {activeAlert?.title || activeAlert?.description || "No active natural disaster warnings. Standard high-altitude trekking precautions apply."}
            </p>
          </div>

          {/* Emergency Helplines & Nearest Hospital/Police */}
          <div className="card-base p-6 shadow-xl border border-purple-100 rounded-3xl space-y-4">
            <h3 className="font-bold text-base text-gray-900 flex items-center gap-2">
              <FiPhoneCall className="text-rose-600" /> Emergency & Medical Contacts
            </h3>

            <div className="space-y-3 text-xs">
              <div className="p-3 rounded-xl bg-gray-50 border border-gray-100">
                <p className="font-bold text-gray-800">Nearest Hospital / Clinic</p>
                <p className="text-purple-700 font-semibold mt-0.5">
                  {destination.nearest_hospital_info || "District Zonal Hospital"}
                </p>
              </div>

              <div className="p-3 rounded-xl bg-gray-50 border border-gray-100">
                <p className="font-bold text-gray-800">Nearest Police Station</p>
                <p className="text-purple-700 font-semibold mt-0.5">
                  {destination.nearest_police_info || "Tourist Police Helpdesk (1144)"}
                </p>
              </div>

              <div className="p-3 rounded-xl bg-rose-50 border border-rose-100 text-rose-950">
                <p className="font-bold">National 24/7 Tourist Helplines</p>
                <p className="mt-1">Tourist Police: <b>1144</b> · Police: <b>100</b> · Ambulance: <b>102</b></p>
              </div>
            </div>

            <button
              onClick={() => navigate("/emergency")}
              className="w-full py-2.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs shadow-md transition-all"
            >
              Open Live Emergency & Hospital Map
            </button>
          </div>

          {/* Translation quick button */}
          <button
            onClick={() => navigate(`/translation?place=${encodeURIComponent(destination.name)}`)}
            className="btn-outline w-full py-3 rounded-2xl flex items-center justify-center gap-2 font-semibold text-xs text-purple-800 border-purple-200 hover:bg-purple-50"
          >
            <FiGlobe size={15} /> Translate Destination to My Language
          </button>
        </div>
      </div>

      {/* FULLSCREEN LIGHTBOX MODAL */}
      <AnimatePresence>
        {lightboxOpen && (
          <div className="fixed inset-0 z-50 bg-black/95 flex flex-col justify-between p-4 sm:p-6 backdrop-blur-md">
            <div className="flex items-center justify-between text-white border-b border-white/10 pb-3">
              <span className="font-bold text-base text-amber-300">
                {destination.name} · Photo {activeImageIdx + 1} of {allImages.length}
              </span>
              <button
                onClick={() => setLightboxOpen(false)}
                className="p-2 rounded-full bg-white/20 hover:bg-white/40 text-white transition-all"
              >
                <FiX size={24} />
              </button>
            </div>

            <div className="flex-1 flex items-center justify-center relative my-4">
              <img
                src={activeImage}
                alt="Fullscreen view"
                className="max-h-[78vh] max-w-full object-contain rounded-2xl shadow-2xl"
              />
              <button
                onClick={() => setActiveImageIdx((p) => (p === 0 ? allImages.length - 1 : p - 1))}
                className="absolute left-2 sm:left-6 p-4 rounded-full bg-black/50 hover:bg-black/80 text-white backdrop-blur transition-all"
              >
                <FiChevronLeft size={28} />
              </button>
              <button
                onClick={() => setActiveImageIdx((p) => (p === allImages.length - 1 ? 0 : p + 1))}
                className="absolute right-2 sm:right-6 p-4 rounded-full bg-black/50 hover:bg-black/80 text-white backdrop-blur transition-all"
              >
                <FiChevronRight size={28} />
              </button>
            </div>

            <div className="flex gap-2 overflow-x-auto justify-center pb-2">
              {allImages.map((url, i) => (
                <button
                  key={i}
                  onClick={() => setActiveImageIdx(i)}
                  className={`w-16 h-12 rounded-lg overflow-hidden shrink-0 border-2 ${
                    activeImageIdx === i ? "border-amber-400 scale-110" : "border-transparent opacity-50"
                  }`}
                >
                  <img src={url} alt={`Thumb ${i}`} className="w-full h-full object-cover" />
                </button>
              ))}
            </div>
          </div>
        )}
      </AnimatePresence>
    </div>
  )
}

export default DestinationDetails
